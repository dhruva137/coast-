"""Domain-randomized wrapper around datasets.synthetic_tw.

datasets/synthetic_tw.py's coordinated-turn kinematics (bible F1-F5) are
correct and untouched here -- this module never re-derives them. Its
noise/mount/tire parameters (VIB_A, VIB_W, GYRO_ARW, ACCEL_ND) are FIXED
module-level constants; this wraps its output with a second, randomized
perturbation layer, per Tobin et al.'s domain randomization: randomize
simulation parameters widely enough that real held-out logs, whenever
they exist, look like an interpolation rather than an extrapolation.

Two deliberately separate randomization scales:
  - `mount_angle_std_deg` (default 6 deg): models RESIDUAL mount-angle
    error left after calibration, not an arbitrary raw-phone orientation.
    lab/models/backbone.py already expects body/vehicle-frame IMU (the
    axis contract + lab/advanced/gyro_mount_calibration.py handle the
    large offset upstream) -- training against a full uncorrected random
    orientation would teach the network to compensate for a problem a
    different module already owns. If you want a stress-test pass that
    also covers calibration FAILURE, raise this well past 6 deg and treat
    the run as its own labeled experiment, not the default training set.
  - `chassis_damping_range` / `extra_tone_*`: tire-pressure-equivalent
    suspension/vibration transfer-function variation, and an optional
    random mount-looseness tone. Coarse physical proxies, not a suspension
    model -- said plainly so nobody over-reads the specific numbers.

docs/ENTERPRISE_BLOCKERS.md names zero real two-wheeler field logs as the
single biggest blocker. This does not fix that -- it only widens what a
handful of real logs, once collected, will be able to fine-tune against.

Every window this module emits is SYNTHETIC. Never blend its output into
a REAL CAR table in whatever lab/proof/evidence_manifest.py produces.
"""

from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np

try:
    from .synthetic_tw import G, IMU_HZ_IO_VNBD, WindowBatch, VehicleKind, generate_trace, _windows_from_trace
except ImportError:  # script / path-bootstrap import
    from synthetic_tw import G, IMU_HZ_IO_VNBD, WindowBatch, VehicleKind, generate_trace, _windows_from_trace  # type: ignore


@dataclass
class DomainRandomConfig:
    mount_angle_std_deg: float = 6.0  # residual roll/pitch/yaw jitter AFTER nominal calibration
    chassis_damping_range: tuple[float, float] = (0.5, 2.5)  # tire-pressure/suspension vibration multiplier
    extra_tone_prob: float = 0.5  # probability of an added mount-looseness tone
    extra_tone_amp_g: tuple[float, float] = (0.02, 0.12)
    extra_tone_hz: tuple[float, float] = (8.0, 45.0)


def _random_small_rotation(rng: np.random.Generator, std_deg: float) -> np.ndarray:
    """Independent roll/pitch/yaw jitter, ZYX composition. Small-angle by construction
    (std_deg is meant to stay in the few-degree range -- see class docstring)."""
    roll, pitch, yaw = np.deg2rad(rng.normal(0.0, std_deg, size=3))
    cr, sr = np.cos(roll), np.sin(roll)
    cp, sp = np.cos(pitch), np.sin(pitch)
    cy, sy = np.cos(yaw), np.sin(yaw)
    rx = np.array([[1, 0, 0], [0, cr, -sr], [0, sr, cr]])
    ry = np.array([[cp, 0, sp], [0, 1, 0], [-sp, 0, cp]])
    rz = np.array([[cy, -sy, 0], [sy, cy, 0], [0, 0, 1]])
    return rz @ ry @ rx


def randomize_trace(tr: dict[str, np.ndarray], rng: np.random.Generator, cfg: DomainRandomConfig) -> dict[str, np.ndarray]:
    """Apply the randomization layer to one generate_trace() output. Labels (speed, psi_dot,
    roll_res, pitch_res, phi) are the true kinematic quantities and are NOT touched -- only the
    `imu` channels change, exactly matching what a real, imperfectly-calibrated mount would do
    to the observed signal without changing the vehicle's actual motion.
    """
    imu = tr["imu"].astype(np.float64).copy()
    accel = imu[:, 0:3]
    gyro = imu[:, 3:6]

    rot = _random_small_rotation(rng, cfg.mount_angle_std_deg)
    accel = accel @ rot.T
    gyro = gyro @ rot.T

    damping = float(rng.uniform(*cfg.chassis_damping_range))
    n = accel.shape[0]
    if n >= 5:
        kernel = np.ones(5) / 5.0
        smooth = np.stack([np.convolve(accel[:, k], kernel, mode="same") for k in range(3)], axis=1)
        high_freq_residual = accel - smooth
        accel = smooth + high_freq_residual * damping

    if rng.random() < cfg.extra_tone_prob and "t" in tr:
        amp = float(rng.uniform(*cfg.extra_tone_amp_g)) * G
        hz = float(rng.uniform(*cfg.extra_tone_hz))
        phase = float(rng.uniform(0.0, 2.0 * np.pi))
        tone = amp * np.sin(2.0 * np.pi * hz * tr["t"] + phase)
        axis = int(rng.integers(0, 3))
        accel[:, axis] = accel[:, axis] + tone

    out = dict(tr)
    out["imu"] = np.concatenate([accel, gyro], axis=1).astype(np.float32)
    return out


def generate_randomized_windows(
    n_windows: int = 4096,
    *,
    seed: int = 7,
    tw_frac: float = 0.6,
    hz: float = IMU_HZ_IO_VNBD,
    duration_s: float = 5.0,
    domain_cfg: DomainRandomConfig | None = None,
) -> WindowBatch:
    """Drop-in for datasets.synthetic_tw.generate_windows -- same signature and return type,
    with the randomization layer applied per-trace before windowing. Swap the import in
    train_avnet.py (documented in INTEGRATION.md) to use this for a domain-randomized pretraining
    pass; keep the original for the non-randomized baseline comparison.
    """
    cfg = domain_cfg or DomainRandomConfig()
    rng = np.random.default_rng(int(seed))
    n_tw = int(round(n_windows * tw_frac))
    n_car = n_windows - n_tw
    kinds: list[VehicleKind] = ["tw"] * n_tw + ["car"] * n_car
    rng.shuffle(kinds)

    imu: np.ndarray | None = None  # shape fixed on first trace, since window length depends on hz
    speed = np.empty(n_windows, dtype=np.float32)
    psi_dot = np.empty(n_windows, dtype=np.float32)
    roll_res = np.empty(n_windows, dtype=np.float32)
    pitch_res = np.empty(n_windows, dtype=np.float32)
    phi = np.empty(n_windows, dtype=np.float32)
    vehicle = np.empty(n_windows, dtype=np.int8)

    for i, kind in enumerate(kinds):
        tr = generate_trace(kind, duration_s=duration_s, hz=hz, rng=rng)
        tr = randomize_trace(tr, rng, cfg)
        w = _windows_from_trace(tr, kind, rng)
        if imu is None:
            imu = np.empty((n_windows,) + w["imu"].shape, dtype=np.float32)
        imu[i] = w["imu"]
        speed[i] = w["speed"]
        psi_dot[i] = w["psi_dot"]
        roll_res[i] = w["roll_res"]
        pitch_res[i] = w["pitch_res"]
        phi[i] = w["phi"]
        vehicle[i] = w["vehicle"]

    assert imu is not None
    return WindowBatch(
        imu=imu, speed=speed, psi_dot=psi_dot, roll_res=roll_res,
        pitch_res=pitch_res, phi=phi, vehicle=vehicle, hz=hz, window_s=imu.shape[1] / hz,
    )


if __name__ == "__main__":
    baseline_rng = np.random.default_rng(1)
    trace = generate_trace("tw", duration_s=5.0, hz=IMU_HZ_IO_VNBD, rng=baseline_rng)
    randomized = randomize_trace(trace, np.random.default_rng(2), DomainRandomConfig())
    delta = np.abs(randomized["imu"] - trace["imu"]).mean()
    labels_unchanged = np.allclose(trace["phi"], trace["phi"])  # sanity: labels come from `trace`, never `randomized`
    print(f"[smoke test] mean |imu delta| after randomization = {delta:.4f} (should be > 0)")
    wb = generate_randomized_windows(n_windows=64, seed=3, duration_s=5.0)
    print(f"[smoke test] generated {len(wb)} randomized windows, imu shape={wb.imu.shape}")
