"""Offline smoother-as-teacher: better training labels than raw instantaneous
CAN/GPS, plus an honest teacher-ceiling vs student-measured report.

docs/ADVANCED_ESTIMATOR_ROADMAP.md already plans a 3-5 s fixed-lag smoother
(GTSAM IncrementalFixedLagSmoother + CombinedImuFactor) as a LIVE retro-
correction path behind the forward InEKF -- that is a bigger, still-
unbuilt undertaking (rank #3 in the roadmap, "port... to C++/WASM" is
listed as future work). This module is deliberately smaller and serves a
different purpose: a pragmatic two-pass Rauch-Tung-Striebel smoother over
a simple constant-acceleration state per channel (speed, yaw-rate), built
to generate better OFFLINE TRAINING LABELS for lab/models/backbone.py
today, not to replace the planned live smoother. When the roadmap's real
smoother lands, retarget this module's `smooth_trajectory` to call it
instead of the toy 2-state model below -- don't maintain two competing
smoothers long-term.

Why a smoothed label beats a raw instantaneous one: at any single instant,
CAN speed / GPS-derived yaw rate carry their own measurement noise. A
smoother that has seen the WHOLE trajectory (forward pass, then backward
pass) can average that noise down using information the causal, on-device
model structurally cannot use (it only ever sees the past). Training
backbone.py's regression heads against the smoothed trajectory instead of
the raw instantaneous CAN/GPS sample is strictly a better label, at zero
runtime cost -- it only touches the training pipeline.

Report BOTH of:
  - teacher ceiling: the smoother's own accuracy vs. real CAN ground
    truth, using an INDEPENDENT observation channel as smoothing input
    (e.g. GPS-derived speed/yaw, not CAN itself -- smoothing CAN against
    CAN would be circular).
  - student measured: backbone.py's causal (real-time) accuracy vs. the
    same CAN ground truth.
The gap between them is the honest headroom left in the causal model.
Do not present the teacher ceiling as an achievable on-device number --
it is not causal and never will be on a phone.
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np


@dataclass
class RtsConfig:
    dt_s: float = 0.1  # IO-VNBD is 10 Hz
    process_noise: float = 0.6  # accel-channel process noise (m/s^3-ish, tune per corpus)
    obs_noise: float = 1.5  # observation noise of the (noisy) input channel being smoothed


def _rts_smooth_1d(obs: np.ndarray, dt: float, q: float, r: float) -> np.ndarray:
    """Two-pass RTS smoother, state = [value, rate-of-change], constant-acceleration model.
    Returns the smoothed `value` series only (same length as `obs`). NaNs in `obs` are treated
    as missing (skip the update, propagate prediction only) so a gappy GPS/CAN log still smooths.
    """
    n = obs.shape[0]
    f = np.array([[1.0, dt], [0.0, 1.0]])
    h = np.array([[1.0, 0.0]])
    q_mat = q * np.array([[dt**3 / 3.0, dt**2 / 2.0], [dt**2 / 2.0, dt]])
    r_scalar = r**2

    x_filt = np.zeros((n, 2))
    p_filt = np.zeros((n, 2, 2))
    x_pred = np.zeros((n, 2))
    p_pred = np.zeros((n, 2, 2))

    x = np.array([obs[0] if np.isfinite(obs[0]) else 0.0, 0.0])
    p = np.eye(2) * 10.0

    for k in range(n):
        if k == 0:
            x_pred[k], p_pred[k] = x, p
        else:
            x_pred[k] = f @ x_filt[k - 1]
            p_pred[k] = f @ p_filt[k - 1] @ f.T + q_mat

        if np.isfinite(obs[k]):
            y = obs[k] - (h @ x_pred[k])[0]
            s = (h @ p_pred[k] @ h.T)[0, 0] + r_scalar
            k_gain = (p_pred[k] @ h.T).flatten() / s
            x_filt[k] = x_pred[k] + k_gain * y
            p_filt[k] = p_pred[k] - np.outer(k_gain, h @ p_pred[k])
        else:
            x_filt[k] = x_pred[k]
            p_filt[k] = p_pred[k]

    x_smooth = x_filt.copy()
    p_smooth = p_filt.copy()
    for k in range(n - 2, -1, -1):
        p_pred_next = p_pred[k + 1]
        try:
            c = p_filt[k] @ f.T @ np.linalg.inv(p_pred_next)
        except np.linalg.LinAlgError:
            c = p_filt[k] @ f.T @ np.linalg.pinv(p_pred_next)
        x_smooth[k] = x_filt[k] + c @ (x_smooth[k + 1] - x_pred[k + 1])
        p_smooth[k] = p_filt[k] + c @ (p_smooth[k + 1] - p_pred_next) @ c.T

    return x_smooth[:, 0]


def smooth_trajectory(
    obs_speed_mps: np.ndarray,
    obs_yaw_rate_rps: np.ndarray,
    cfg: RtsConfig = RtsConfig(),
) -> dict[str, np.ndarray]:
    """Smooth speed and yaw-rate independently (they're only weakly coupled at this level of
    approximation -- coupling them properly is exactly the bigger job the roadmap's InEKF-based
    smoother is for). Returns {"speed": ..., "yaw_rate": ...}, same length as the inputs.
    """
    return {
        "speed": _rts_smooth_1d(obs_speed_mps, cfg.dt_s, cfg.process_noise, cfg.obs_noise),
        "yaw_rate": _rts_smooth_1d(obs_yaw_rate_rps, cfg.dt_s, cfg.process_noise, cfg.obs_noise),
    }


@dataclass
class TeacherStudentReport:
    teacher_speed_mae: float
    student_speed_mae: float
    teacher_yaw_mae: float
    student_yaw_mae: float
    n_samples: int

    def headroom_speed(self) -> float:
        return self.student_speed_mae - self.teacher_speed_mae

    def headroom_yaw(self) -> float:
        return self.student_yaw_mae - self.teacher_yaw_mae


def evaluate_teacher_vs_student(
    smoothed: dict[str, np.ndarray],
    student_speed_pred: np.ndarray,
    student_yaw_pred: np.ndarray,
    can_truth_speed: np.ndarray,
    can_truth_yaw: np.ndarray,
) -> TeacherStudentReport:
    """THE acceptance test for item #6: two explicit numbers, not a claim. `smoothed` must have
    been produced from an observation channel independent of `can_truth_*` (e.g. GPS-derived),
    or this comparison is circular and worthless -- check that before trusting the report.
    """
    valid = np.isfinite(can_truth_speed) & np.isfinite(can_truth_yaw)
    return TeacherStudentReport(
        teacher_speed_mae=float(np.mean(np.abs(smoothed["speed"][valid] - can_truth_speed[valid]))),
        student_speed_mae=float(np.mean(np.abs(student_speed_pred[valid] - can_truth_speed[valid]))),
        teacher_yaw_mae=float(np.mean(np.abs(smoothed["yaw_rate"][valid] - can_truth_yaw[valid]))),
        student_yaw_mae=float(np.mean(np.abs(student_yaw_pred[valid] - can_truth_yaw[valid]))),
        n_samples=int(valid.sum()),
    )


if __name__ == "__main__":
    rng = np.random.default_rng(26168)
    n = 300
    dt = 0.1
    t = np.arange(n) * dt
    true_speed = 12.0 + 3.0 * np.sin(0.15 * t)
    true_yaw = 0.2 * np.sin(0.1 * t)

    noisy_speed = true_speed + rng.normal(0, 1.2, size=n)  # stand-in for a noisy GPS-derived channel
    noisy_yaw = true_yaw + rng.normal(0, 0.15, size=n)

    smoothed = smooth_trajectory(noisy_speed, noisy_yaw)
    print(f"[smoke test] raw MAE vs truth:      speed={np.mean(np.abs(noisy_speed - true_speed)):.3f} "
          f"yaw={np.mean(np.abs(noisy_yaw - true_yaw)):.3f}")
    print(f"[smoke test] smoothed MAE vs truth: speed={np.mean(np.abs(smoothed['speed'] - true_speed)):.3f} "
          f"yaw={np.mean(np.abs(smoothed['yaw_rate'] - true_yaw)):.3f}  (should both be lower than raw)")

    fake_student_speed = true_speed + rng.normal(0, 0.8, size=n)
    fake_student_yaw = true_yaw + rng.normal(0, 0.1, size=n)
    report = evaluate_teacher_vs_student(smoothed, fake_student_speed, fake_student_yaw, true_speed, true_yaw)
    print(f"[smoke test] teacher/student report: {report}")
