"""Self-supervised masked-reconstruction pretraining for backbone.FrequencyDecoupledNet.

Nothing in the repo does this yet: lab/models/backbone.py / train_avnet.py train
FrequencyDecoupledNet's regression heads only on labeled windows (forced-outage
segments with CAN/GPS ground truth). The ~57+ hours of IO-VNBD OUTSIDE those
labeled windows carry no labels and are currently unused for representation
learning.

Follows the general approach of LIMU-BERT (Xu et al.): mask a span of the input
window, train the shared encoder to reconstruct it, then fine-tune the existing
regression heads on labeled data. IO-VNBD's 2.0s/20-sample window (per
backbone.py's own comment: "IO-VNBD is 10 Hz... 20 samples, not 200 @ 200 Hz")
is short relative to LIMU-BERT's original scale -- masking here is a short
contiguous span (2-4 samples), not a large patch, so the pretext task stays
solvable from local context instead of being trivial or impossible at this
window length.

Reuses FrequencyDecoupledNet's own submodules (split, low_proj, gru) exactly as
backbone.py defines them -- does not modify backbone.py, does not fork a second
feature extractor. Scope note: only the LOW-band path (split -> low_proj -> gru)
is pretrained here, because it's the only branch that still carries a
per-timestep representation to reconstruct against (high_adapter's own forward
pools to one vector per window via `.mean(dim=-1)`, which has nothing to
reconstruct a per-timestep target from without restructuring that branch --
left out of scope rather than bolted on awkwardly). `head` is untrained by this
objective and stays randomly initialized until fine-tuning.

Acceptance test for item #4 (run this, don't assume it): train the SAME
architecture (a) from scratch on labeled data only, and (b) pretrained here
then fine-tuned on the same labeled data -- report both validation losses on
the same held-out split train_avnet.py already uses. See `if __name__` below
for a plumbing-only smoke test; the real ablation needs actual IO-VNBD windows.
"""

from __future__ import annotations

import sys
from dataclasses import dataclass
from pathlib import Path

import numpy as np
import torch
import torch.nn as nn

_LAB = Path(__file__).resolve().parents[1]
if str(_LAB) not in sys.path:
    sys.path.insert(0, str(_LAB))

from models.backbone import FrequencyDecoupledNet, build_model  # noqa: E402


@dataclass
class SslConfig:
    mask_span: int = 3  # contiguous masked timesteps per sample (window is 20 samples -- see module docstring)
    mask_prob: float = 0.6  # fraction of windows in a batch that get a mask applied at all
    lr: float = 3e-4
    epochs: int = 20
    batch_size: int = 256


class ReconstructionHead(nn.Module):
    """Discarded after pretraining. Maps the GRU's full per-timestep sequence output
    back to a 6-channel reconstruction -- backbone.py's own forward() only keeps the
    final hidden state (h_n[-1]); this is the only place that also reads the sequence
    output, since nothing else in backbone.py needs it.
    """

    def __init__(self, gru_hidden: int, in_ch: int = 6):
        super().__init__()
        self.proj = nn.Sequential(
            nn.Linear(gru_hidden, 64),
            nn.GELU(),
            nn.Linear(64, in_ch),
        )

    def forward(self, gru_seq_out: torch.Tensor) -> torch.Tensor:
        """`gru_seq_out` is (B, T, gru_hidden) -> returns (B, T, in_ch)."""
        return self.proj(gru_seq_out)


def _mask_window(x: torch.Tensor, cfg: SslConfig, rng: torch.Generator) -> tuple[torch.Tensor, torch.Tensor]:
    """`x` is (B, C, T). Returns (masked_x, mask) where mask is (B, T) bool, True where masked."""
    b, _c, t = x.shape
    masked = x.clone()
    mask = torch.zeros(b, t, dtype=torch.bool, device=x.device)
    span = min(cfg.mask_span, max(1, t - 1))
    for i in range(b):
        if torch.rand(1, generator=rng).item() > cfg.mask_prob:
            continue
        start = int(torch.randint(0, max(1, t - span), (1,), generator=rng).item())
        masked[i, :, start:start + span] = 0.0
        mask[i, start:start + span] = True
    return masked, mask


def _shared_low_band_features(model: FrequencyDecoupledNet, x: torch.Tensor) -> torch.Tensor:
    """Re-run backbone.py's own low-band feature path, keeping the FULL GRU sequence
    output instead of only the final hidden state. Calls model's existing public
    submodules only -- nothing here is reimplemented."""
    x = model._as_bct(x)
    low, _high = model.split(x)
    seq = model.low_proj(low).transpose(1, 2)  # (B, T, 32)
    out, _h_n = model.gru(seq)  # (B, T, gru_hidden)
    return out


def pretrain(
    model: FrequencyDecoupledNet,
    unlabeled_windows: np.ndarray,  # (N, T, 6) or (N, 6, T) -- any layout backbone.py's _as_bct accepts
    cfg: SslConfig = SslConfig(),
    device: str = "cpu",
) -> dict[str, list[float]]:
    """Masked-reconstruction pretraining. Mutates `model`'s split/low_proj/gru submodules
    in place -- `head` and `high_adapter` are untouched by this objective (see module
    docstring) and will still be randomly initialized until the fine-tuning step trains
    them on labeled data via train_avnet.py's existing loop.
    """
    model.to(device)
    decoder = ReconstructionHead(model.gru_hidden, model.in_ch).to(device)
    opt = torch.optim.Adam(
        list(model.split.parameters()) + list(model.low_proj.parameters())
        + list(model.gru.parameters()) + list(decoder.parameters()),
        lr=cfg.lr,
    )
    rng = torch.Generator().manual_seed(26168)

    x_all = torch.tensor(unlabeled_windows, dtype=torch.float32)
    if x_all.shape[-1] == model.in_ch and x_all.shape[1] != model.in_ch:
        x_all = x_all.transpose(1, 2)  # -> (N, C, T)

    losses: list[float] = []
    n = x_all.shape[0]
    for _epoch in range(cfg.epochs):
        perm = torch.randperm(n)
        epoch_loss = 0.0
        n_batches = 0
        for start in range(0, n, cfg.batch_size):
            idx = perm[start:start + cfg.batch_size]
            batch = x_all[idx].to(device)
            masked, mask = _mask_window(batch, cfg, rng)
            seq_out = _shared_low_band_features(model, masked)
            recon = decoder(seq_out).transpose(1, 2)  # -> (B, C, T)
            mask_ct = mask.unsqueeze(1).expand(-1, model.in_ch, -1)
            if mask_ct.sum() == 0:
                continue
            diff = (recon - batch) ** 2
            loss = diff[mask_ct].mean()
            opt.zero_grad()
            loss.backward()
            opt.step()
            epoch_loss += float(loss.item())
            n_batches += 1
        losses.append(epoch_loss / max(1, n_batches))
    return {"pretrain_loss": losses}


if __name__ == "__main__":
    # Plumbing-only smoke test on random data -- checks shapes and that the loss runs/decreases.
    # It does NOT validate the pretrain-vs-scratch ablation; that needs real IO-VNBD windows
    # (see train_avnet.py for the held-out split to run that ablation against).
    rng_np = np.random.default_rng(26168)
    fake_windows = rng_np.normal(0, 1, size=(512, 20, 6)).astype(np.float32)
    model = build_model()
    result = pretrain(model, fake_windows, SslConfig(epochs=5))
    print(f"[smoke test] pretrain loss per epoch: {[round(v, 4) for v in result['pretrain_loss']]}")
    print("[smoke test] a decreasing trend here just confirms the plumbing works (it can memorize "
          "random data too) -- the real signal is the pretrained-vs-scratch delta on held-out, "
          "real, labeled IO-VNBD windows.")
