"""Independent vibration-spectrum speed cross-check + engine-idle ZUPT trigger.

lab/models/backbone.py already splits IMU into a <2 Hz motion band and a
vibration/high-frequency band (FrequencySplit), but that split feeds
FrequencyDecoupledNet's speed regression as a noise-rejection adapter --
it conditions how much the network trusts the motion band, it never turns
the vibration signal itself into a second, independent velocity estimate.

This module is that second, physically separate channel:
  - US Patent 9,842,438 ("Mileage and speed estimation"): a vehicle-mounted
    accelerometer's vibration spectrum carries a peak tracking wheel/engine
    rotation speed.
  - Paramo-Balsa, Roldan-Fernandez, Gonzalez-Longatt, Burgos-Payan,
    Applied Sciences (2022): a smartphone accelerometer alone recovers
    rotating-machinery speed from vibration harmonics to <0.15% error.
  - Li, Nie, Suvorkin, Rovira-Garcia, Zhang, Xu, Xu, Remote Sensing (2024):
    an idling engine gives a stable, identifiable FFT peak distinct from
    the driving vibration signature -- used there as a zero-velocity
    (ZUPT) trigger. This module reuses the same FFT machinery for that.

Calibration follows the same "fit while truth is available, freeze during
the outage" discipline as lab/advanced/gyro_mount_calibration.py. Do not
claim this channel is trustworthy before it's been correlated against real
CAN/GPS speed on the IO-VNBD corpus (see correlate_against_corpus) --
`trusted` defaults to False and stays False until that check passes.
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np

G = 9.80665


@dataclass
class VibrationSpeedConfig:
    fs_hz: float = 10.0  # accelerometer sample rate feeding this module
    window: int = 32  # samples per FFT window
    min_band_hz: float = 0.6  # below this is body/steering sway, not engine/wheel vibration
    max_band_hz: float | None = None  # default: fs/2 minus a small guard band
    idle_peak_min_power: float = 0.5  # fraction of window energy in the idle peak's bin, to call it "idle"


@dataclass
class VibrationSpeedResult:
    dominant_hz: float
    peak_concentration: float  # fraction of in-window spectral energy in the dominant bin


@dataclass
class SpeedCalibration:
    gain: float | None = None
    bias: float = 0.0
    n_fit: int = 0
    correlation: float = float("nan")
    mae_mps: float = float("nan")
    trusted: bool = False
    reason: str = "uncalibrated"


def dominant_frequency(accel_mag_minus_g: np.ndarray, fs_hz: float, min_hz: float, max_hz: float) -> VibrationSpeedResult:
    """FFT of one window of |a| - g. Returns the dominant in-band frequency and its energy concentration."""
    n = int(accel_mag_minus_g.shape[0])
    if n < 8:
        return VibrationSpeedResult(dominant_hz=0.0, peak_concentration=0.0)
    centered = accel_mag_minus_g - accel_mag_minus_g.mean()
    windowed = centered * np.hanning(n)
    spec = np.fft.rfft(windowed)
    power = spec.real**2 + spec.imag**2
    freqs = np.fft.rfftfreq(n, d=1.0 / fs_hz)
    total = float(power[1:].sum())  # skip DC bin
    if total <= 0.0:
        return VibrationSpeedResult(dominant_hz=0.0, peak_concentration=0.0)
    in_band = (freqs >= min_hz) & (freqs <= max_hz)
    band_power = power.copy()
    band_power[~in_band] = -1.0
    band_power[0] = -1.0
    if not np.any(band_power > 0):
        return VibrationSpeedResult(dominant_hz=0.0, peak_concentration=0.0)
    idx = int(np.argmax(band_power))
    return VibrationSpeedResult(dominant_hz=float(freqs[idx]), peak_concentration=float(power[idx] / total))


def fit_calibration(
    freqs_hz: np.ndarray,
    fit_target_mps: np.ndarray,
    holdout_target_mps: np.ndarray | None = None,
) -> SpeedCalibration:
    """speed ~= gain*freq + bias, fit only where target speed > 1 m/s (a standstill carries zero
    gain information). If `holdout_target_mps` differs from `fit_target_mps` (e.g. fit on GPS speed,
    check against CAN speed), correlation/MAE are reported against the holdout -- that's the honest
    acceptance test, not the training residual.
    """
    mask = fit_target_mps > 1.0
    f = freqs_hz[mask]
    v = fit_target_mps[mask]
    if f.size < 8:
        return SpeedCalibration(reason="insufficient_excitation")
    design = np.stack([f, np.ones_like(f)], axis=1)
    gain, bias = np.linalg.lstsq(design, v, rcond=None)[0]

    target = holdout_target_mps if holdout_target_mps is not None else fit_target_mps
    pred = gain * freqs_hz + bias
    valid = target > 1.0
    if not np.any(valid):
        return SpeedCalibration(gain=float(gain), bias=float(bias), n_fit=int(f.size), reason="no_holdout")
    pv, tv = pred[valid], target[valid]
    corr = float(np.corrcoef(pv, tv)[0, 1]) if np.std(pv) > 0 and np.std(tv) > 0 else 0.0
    mae = float(np.mean(np.abs(pv - tv)))
    # Deliberately conservative: this is a cross-check/fallback channel, not the primary speed
    # source, so the bar for `trusted` is a real, sample-backed correlation, not a coin flip.
    trusted = corr > 0.5 and f.size >= 20
    return SpeedCalibration(
        gain=float(gain), bias=float(bias), n_fit=int(f.size),
        correlation=corr, mae_mps=mae, trusted=trusted,
        reason="ok" if trusted else "weak_correlation",
    )


def apply_calibration(freq_hz: float, cal: SpeedCalibration) -> float | None:
    """None (not zero) means "don't use this channel" -- never fabricate a number pre-calibration."""
    if cal.gain is None or not cal.trusted:
        return None
    return max(0.0, cal.gain * freq_hz + cal.bias)


def is_idle(result: VibrationSpeedResult, idle_ref_hz: float, fs_hz: float, window: int, min_power: float) -> bool:
    """Per Li et al. 2024: an idling engine gives a stable, concentrated FFT peak at road speed == 0.
    `idle_ref_hz` is learned once per session by calling this module while ZuptDetector / isStatic()
    already reports stationary-with-engine-running -- this function only compares against it.
    """
    bin_width = fs_hz / window
    close_enough = abs(result.dominant_hz - idle_ref_hz) < 2.0 * bin_width
    return close_enough and result.peak_concentration >= min_power


def correlate_against_corpus(
    windows_imu: np.ndarray,
    can_speed_mps: np.ndarray,
    cfg: VibrationSpeedConfig = VibrationSpeedConfig(),
) -> SpeedCalibration:
    """Run the whole pipeline over a labeled corpus and report whether this channel is worth
    trusting at all -- THIS is the acceptance test for item #3, not an assumption.

    `windows_imu` is (N, T, 6) ax,ay,az,gx,gy,gz -- the same layout as
    datasets.synthetic_tw.WindowBatch.imu / datasets.io_vnbd's window loader.
    `can_speed_mps` is (N,) CAN/GPS speed aligned to each window's last sample.
    """
    max_hz = cfg.max_band_hz if cfg.max_band_hz is not None else (cfg.fs_hz / 2.0 - 0.5)
    freqs = np.zeros(windows_imu.shape[0], dtype=np.float64)
    for i in range(windows_imu.shape[0]):
        mag = np.linalg.norm(windows_imu[i, :, 0:3], axis=1) - G
        freqs[i] = dominant_frequency(mag, cfg.fs_hz, cfg.min_band_hz, max_hz).dominant_hz
    return fit_calibration(freqs, can_speed_mps, can_speed_mps)


if __name__ == "__main__":
    # Smoke test with a synthetic vibration tone whose frequency tracks a fake "speed" --
    # sanity-checks the FFT/calibration plumbing only. Real acceptance test is
    # correlate_against_corpus() against real IO-VNBD windows + paired CAN speed.
    rng = np.random.default_rng(26168)
    fs = 10.0
    n_windows, T = 400, 32
    true_speed = rng.uniform(2.0, 20.0, size=n_windows)
    true_hz = 0.15 * true_speed + 0.4  # made-up but monotonic mapping, for the smoke test only
    imu = np.zeros((n_windows, T, 6), dtype=np.float64)
    t = np.arange(T) / fs
    for i in range(n_windows):
        tone = 0.6 * np.sin(2 * np.pi * true_hz[i] * t) + rng.normal(0, 0.05, size=T)
        imu[i, :, 2] = G + tone  # az carries the vibration tone
    cal = correlate_against_corpus(imu, true_speed, VibrationSpeedConfig(fs_hz=fs, window=T))
    print(f"[smoke test] n_fit={cal.n_fit} correlation={cal.correlation:.3f} mae={cal.mae_mps:.3f} trusted={cal.trusted}")
