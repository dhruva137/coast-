#pragma once

// Branch-stratified, floor-preserving resampling for GraphParticleFilter.
//
// docs/ADVANCED_ESTIMATOR_ROADMAP.md already specifies this design ("merge
// near-identical hypotheses; prune only with a floor so a temporarily weak
// correct branch can recover") — GraphParticleFilter::resample() in
// graphpf.cpp is currently plain systematic resampling with no per-edge
// floor, so a minority route hypothesis can be wiped out in a single
// resampling step even when the underlying road-network ambiguity hasn't
// actually resolved. This is the concrete implementation of that plan.
//
// Does NOT modify graphpf.cpp/.h. Wire it in per INTEGRATION.md: give
// GraphParticleFilter a `StratifiedResampler stratified_;` member and
// replace the body of its private `resample()` method with a call to
// `stratified_.resample(particles, rng_);` — both `particles` and `rng_`
// are accessible from inside the class's own method body.

#include "nav/math.h"
#include "nav/types.h"

#include <map>
#include <string>
#include <unordered_map>
#include <vector>

namespace nav {

struct StratifiedResampleConfig {
  // Floor on a stratum's post-resample weight mass, as a fraction of 1/n
  // per particle — small enough to not distort a confident single-edge
  // lock, large enough that a live minority edge survives one tick.
  double floor_epsilon = 0.02;
  // Ticks a stratum must stay below the floor's trigger threshold before
  // it's allowed to actually disappear — matches the roadmap's "prune
  // only with a floor so a temporarily weak correct branch can recover",
  // not a single-step kill. At a 10 Hz step rate this is ~1.5 s.
  int persistence_ticks = 15;
  // A stratum's raw (pre-floor) weight share below this is considered
  // "starved" for persistence-counting purposes.
  double starved_share = 0.01;
  // Same small along-edge jitter the existing resample() applies, kept
  // for behavioural parity.
  double jitter_sigma_s = 0.002;
};

class StratifiedResampler {
 public:
  explicit StratifiedResampler(StratifiedResampleConfig cfg = {});

  /** Drop-in body for GraphParticleFilter::resample(). Mutates `particles` in place. */
  void resample(std::vector<IParticle>& particles, Rng32& rng);

  /** Reset persistence bookkeeping — call on GraphParticleFilter::seed(). */
  void reset();

  /**
   * Inverse-Simpson effective live-edge count over a mass distribution —
   * e.g. GraphParticleFilter::estimate()'s already-populated
   * `state.branch_posteriors`. 1.0 means fully collapsed onto one edge;
   * higher means genuine multi-hypothesis spread. Report this alongside
   * PASS_ISRO, not instead of it — it's a multi-modality diagnostic, not
   * an accuracy metric.
   */
  static double effectiveLiveEdges(const std::map<std::string, double>& mass_by_edge);

 private:
  StratifiedResampleConfig cfg_;
  std::unordered_map<std::string, int> low_weight_streak_;
};

}  // namespace nav
