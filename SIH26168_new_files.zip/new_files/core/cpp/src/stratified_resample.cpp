#include "nav/stratified_resample.h"

#include <algorithm>
#include <cmath>

namespace nav {

StratifiedResampler::StratifiedResampler(StratifiedResampleConfig cfg) : cfg_(cfg) {}

void StratifiedResampler::reset() { low_weight_streak_.clear(); }

double StratifiedResampler::effectiveLiveEdges(const std::map<std::string, double>& mass_by_edge) {
  double total = 0.0;
  for (const auto& kv : mass_by_edge) total += kv.second;
  if (total <= 0.0) return 0.0;
  double sum_sq = 0.0;
  for (const auto& kv : mass_by_edge) {
    double p = kv.second / total;
    sum_sq += p * p;
  }
  return sum_sq > 0.0 ? 1.0 / sum_sq : 0.0;
}

void StratifiedResampler::resample(std::vector<IParticle>& particles, Rng32& rng) {
  const int n = static_cast<int>(particles.size());
  if (n == 0) return;

  // 1. Aggregate weight mass per edge stratum.
  std::unordered_map<std::string, double> mass_by_edge;
  double total_weight = 0.0;
  for (const auto& p : particles) {
    mass_by_edge[p.edge_id] += p.weight;
    total_weight += p.weight;
  }
  if (total_weight <= 0.0) {
    for (auto& p : particles) p.weight = 1.0 / n;
    return;
  }

  // 2. Persistence bookkeeping: a stratum keeps its floor protection until
  // it has read below `starved_share` for `persistence_ticks` consecutive
  // calls — a single bad tick can't wipe out a hypothesis that's actually
  // still resolving, but one that never recovers still eventually loses
  // its floor and is allowed to disappear.
  std::unordered_map<std::string, bool> floor_protected;
  for (const auto& kv : mass_by_edge) {
    double share = kv.second / total_weight;
    if (share < cfg_.starved_share) {
      int& streak = low_weight_streak_[kv.first];
      streak += 1;
      floor_protected[kv.first] = streak < cfg_.persistence_ticks;
    } else {
      low_weight_streak_[kv.first] = 0;
      floor_protected[kv.first] = true; // floor is a no-op for a healthy stratum anyway
    }
  }
  // Forget edges no longer present so this doesn't grow unbounded over a long ride.
  for (auto it = low_weight_streak_.begin(); it != low_weight_streak_.end();) {
    if (mass_by_edge.find(it->first) == mass_by_edge.end()) {
      it = low_weight_streak_.erase(it);
    } else {
      ++it;
    }
  }

  // 3. Build floored draw weights.
  const double floor_w = cfg_.floor_epsilon / static_cast<double>(n);
  std::vector<double> draw_w(n);
  double draw_total = 0.0;
  for (int i = 0; i < n; ++i) {
    double w = particles[i].weight / total_weight;
    if (floor_protected[particles[i].edge_id]) w = std::max(w, floor_w);
    draw_w[i] = w;
    draw_total += w;
  }
  if (draw_total <= 0.0) {
    for (auto& p : particles) p.weight = 1.0 / n;
    return;
  }

  // 4. Systematic resampling on the floored weights (same low-variance
  // scheme as the existing resample(), just drawing from `draw_w` instead
  // of raw normalized weight).
  std::vector<IParticle> resampled;
  resampled.reserve(n);
  const double step = draw_total / n;
  double u = rng.next() * step;
  double cum = draw_w[0];
  int idx = 0;
  for (int i = 0; i < n; ++i) {
    double target = u + i * step;
    while (cum < target && idx < n - 1) {
      ++idx;
      cum += draw_w[idx];
    }
    IParticle src = particles[idx];
    src.s = clamp(src.s + cfg_.jitter_sigma_s * gauss(rng), 0.0, 1.0);
    src.weight = 1.0 / n;
    resampled.push_back(src);
  }
  particles.swap(resampled);
}

}  // namespace nav
