# AUDIT_DELTA.md — what already existed vs. what this pass added

## Confirmed already present (not rebuilt — see prior turn's grounded audit for the full list)
- `lab/advanced/gyro_mount_calibration.py` — GNSS-supervised yaw scale/bias calibration, Huber-IRLS,
  Mahalanobis OOD gate, conformal quantile (`conformal_q90_rps`) already computed.
- `lab/models/backbone.py` (`FrequencyDecoupledNet`) — already body-frame, already frequency-split at
  the F7 ~2 Hz motion/vibration boundary.
- `lab/proof/blind_challenge.py` — commit-reveal already literal SHA-256 pre-registration.
- `core/cpp/src/graphpf.cpp` (`GraphParticleFilter`) — real particle filter on the road graph: junction
  softmax by heading likelihood, adaptive horizon (F10), light-pulse and barometer likelihoods.
  Verified its public API directly (`seed`, `step`, `estimate`, `mapProject`) rather than assumed.
- `core/cpp/src/preprocess.cpp` `isStatic()` — single-sample threshold ZUPT already exists in C++/TS.
- `core/cpp/bindings/jni/nav_jni.cpp` — confirmed to be an intentional placeholder, with a documented
  15 Oct JNI+WASM go/no-go and an explicit fallback plan ("fork the core into Kotlin and TypeScript
  instead") if it isn't green by then. This changed how item #1 below was scoped — see its own header.
- `docs/ADVANCED_ESTIMATOR_ROADMAP.md` already specifies branch-stratified/floor-preserving resampling
  in words ("merge near-identical hypotheses; prune only with a floor") and a 3–5s fixed-lag smoother
  (GTSAM `IncrementalFixedLagSmoother` + `CombinedImuFactor`) as a live retro-correction path — neither
  was implemented in code yet. Confirmed by reading `graphpf.cpp`'s actual `resample()` (plain
  systematic, no floor) and grepping the repo for "smooth"/"rts" (nothing beyond the roadmap doc's own
  prose).

## Added this pass — every one has a passing local test, cited below

| File | What it is | Verified how |
|---|---|---|
| `core/cpp/include/nav/stratified_resample.h` + `.../src/stratified_resample.cpp` | Branch-stratified, floor-preserving resampling + inverse-Simpson effective-live-edges metric | Compiled against real `graphpf.h`/`types.h`/`math.h`; isolated test confirms a heavily-starved edge stratum keeps ~1.5% mass instead of hitting zero in one step |
| `android/app/src/main/cpp/nav_jni_bridge.cpp` + `CMakeLists.txt` + `android/.../nav/NativeEngine.kt` | JNI proof-of-concept wiring `GraphParticleFilter` into a persistent, handle-based call surface a phone can actually use per-tick | Compiled and LINKED against the real `graphpf.cpp`/`math.cpp` object files with a stub `jni.h`; ran a full create→seed→step×20→estimate→destroy sequence and got back a real, sane `INavState` JSON (edge lock, branch posteriors summing sensibly) |
| `lab/models/vibration_speed.py` | Independent FFT vibration-speed cross-check + engine-idle ZUPT trigger | Ran; synthetic smoke test recovers correlation 0.993 against a planted frequency-to-speed mapping |
| `lab/models/smoothed_teacher.py` | Two-pass RTS smoother for offline training-label generation + teacher-ceiling/student-measured report | Ran; smoke test shows MAE dropping from 0.96→0.13 (speed) and 0.13→0.03 (yaw) after smoothing a noisy synthetic signal against known truth |
| `lab/datasets/domain_randomize.py` | Domain-randomized wrapper around `synthetic_tw.generate_trace`/`generate_windows` (mount-angle residual jitter, chassis-damping multiplier, optional looseness tone) | Ran against the REAL `synthetic_tw.py` (not a mock) — produced correctly-shaped `(N, 20, 6)` windows matching the existing `WindowBatch` contract exactly |
| `lab/models/pretrain_ssl.py` | Masked-reconstruction self-supervised pretraining for `FrequencyDecoupledNet`'s shared low-band path | Syntax-checked only (`py_compile` passed) — **not runtime-tested**, `torch` could not be installed in this sandbox (no disk space for the wheel). Run its own `__main__` smoke test yourself before trusting the plumbing, and definitely before trusting the pretrain-vs-scratch ablation number |
| `android/.../sensor/GnssQualityMonitor.kt` | GNSS raw C/N0 trend early-warning signal | Delivered in an earlier pass of this project; re-confirmed the package path (`in.sih26168.idr.sensor`) matches this repo's real structure |

## Honesty notes
- The JNI proof-of-concept only loads the built-in synthetic `defaultCampusGraph()` — it does not load
  a real OSM extract yet. Don't present a walk-test against it as evidence the real map works on-device,
  only that the JNI plumbing itself does.
- `pretrain_ssl.py` is unverified at runtime. Everything else in this delta was actually executed
  against real code (not mocks) in this pass, and the exact commands to reproduce each result are in
  each file's own `if __name__ == "__main__":` block.
