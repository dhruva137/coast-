# INTEGRATION.md — manual wiring for the new files

Every step below is something YOU apply by hand to an existing file. Nothing in this task touched
those files directly, per the "never modify existing files" rule.

## 1. JNI bridge (items: CMakeLists.txt, nav_jni_bridge.cpp, NativeEngine.kt)

In `android/app/build.gradle.kts`, inside the `android { defaultConfig { ... } }` block, add:

```kotlin
externalNativeBuild {
    cmake {
        cppFlags += "-std=c++17"
    }
}
```

And at the `android { ... }` level (sibling of `defaultConfig`), add:

```kotlin
externalNativeBuild {
    cmake {
        path = file("src/main/cpp/CMakeLists.txt")
        version = "3.22.1"
    }
}
```

You'll need `ndkVersion "26.1.10909125"` (or whatever LTS NDK your `local.properties`/SDK manager
already has) in the same `android { ... }` block if one isn't already declared.

This is a proof-of-concept scoped to the built-in `defaultCampusGraph()` (see `nav_jni_bridge.cpp`'s
own header comment) — it exists to give real data (build success, `.so` size, on-device `step()`
latency) to the documented 15 Oct JNI+WASM go/no-go, not to presume its outcome. If the go/no-go is
"no," delete `android/app/src/main/cpp/` and `NativeEngine.kt` — nothing else references them.

Real-graph loading (parsing an OSM extract bundled as an Android asset into an `IRoadGraph` and
passing it through the JNI boundary) is a deliberate follow-up, not built here, to keep this a small,
reviewable first cut.

## 2. Branch-stratified resampling (items: stratified_resample.h/.cpp)

In `core/cpp/include/nav/graphpf.h`, add a member to the private section of `GraphParticleFilter`:

```cpp
#include "nav/stratified_resample.h"   // new include at the top of the file
...
private:
  void normalize();
  double ess() const;
  void resample();          // <- leave this declaration; only its .cpp BODY changes below
  StratifiedResampler stratified_;   // <- new member
```

In `core/cpp/src/graphpf.cpp`, replace the **body** of `GraphParticleFilter::resample()` with:

```cpp
void GraphParticleFilter::resample() {
  stratified_.resample(particles, rng_);
}
```

(`particles` and `rng_` are private members already accessible from inside the class's own method —
no other signature changes needed.) Also call `stratified_.reset()` from inside `seed()`, next to
whatever else `seed()` already resets.

To surface the multi-modality diagnostic, call `StratifiedResampler::effectiveLiveEdges(state.
branch_posteriors)` wherever `estimate()`'s result is consumed (e.g. in `lab/stress/run_mapfilter_
eval.py`-equivalent evaluation code, or in `NativeEngine.kt`'s `NativeFix.effectiveLiveEdges()`,
already implemented client-side in this delivery as a stopgap).

Verified: `stratified_resample.cpp` compiles against the real `graphpf.h`/`types.h`/`math.h` and, in
an isolated test, correctly keeps ~1.5% of the mass alive on a heavily-starved edge stratum instead of
letting it hit exactly zero in one resampling step — see the delivered file's header comment for the
exact test setup if you want to reproduce it.

## 3. Vibration speed + smoothed teacher + SSL pretraining + domain randomization (Python)

None of these require touching an existing file to RUN standalone (`python3 lab/models/vibration_
speed.py`, `python3 lab/models/smoothed_teacher.py`, `python3 lab/datasets/domain_randomize.py` all
have a `__main__` smoke test and ran clean in this environment; `lab/models/pretrain_ssl.py`'s smoke
test needs `torch`, which was not installable in the sandbox this was built in — please run it
yourself before trusting the pretrain-vs-scratch ablation number).

To actually use them in the real training pipeline, in `lab/models/train_avnet.py`:

- Swap `from datasets.synthetic_tw import WindowBatch, generate_windows` for
  `from datasets.domain_randomize import generate_randomized_windows as generate_windows` to run a
  domain-randomized pretraining pass — keep a second run with the original import for the
  non-randomized baseline comparison; report both.
- Call `pretrain_ssl.pretrain(model, unlabeled_windows)` on `build_model()`'s output BEFORE the
  existing labeled-data training loop, using all available IMU (not just labeled outage windows) as
  `unlabeled_windows`, then continue into the existing loop unchanged for fine-tuning.
- Call `smoothed_teacher.smooth_trajectory(...)` on a real drive's GPS-derived speed/yaw (NOT CAN, to
  keep the ceiling comparison non-circular — see that file's own docstring), and use its output as the
  regression target instead of raw instantaneous CAN/GPS wherever `train_avnet.py` currently builds
  labels from the real corpus.

Each of these is additive — the existing from-scratch / non-randomized / non-smoothed path still
works exactly as it does today if you don't make the swap.

## 4. GNSS raw-measurement early warning (item #7)

Already delivered in an earlier pass of this project as `GnssQualityMonitor.kt`
(`in.sih26168.idr.sensor`, `GnssMeasurementsEvent`-based C/N0 trend tracker) — unchanged, still valid
against the real package structure confirmed in this audit. Per the original sequencing note: wire it
in only once item #1's `NativeEngine`/mode-manager surface actually exists to feed a `degrading` signal
into — there's nothing for it to drive yet on its own.
