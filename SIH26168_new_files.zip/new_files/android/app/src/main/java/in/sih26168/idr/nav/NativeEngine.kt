package `in`.sih26168.idr.nav

/**
 * Kotlin call surface for the native GraphParticleFilter, via
 * android/app/src/main/cpp/nav_jni_bridge.cpp -> core/cpp's already-existing,
 * already-tested nav::GraphParticleFilter. No estimator math lives here or in
 * the bridge -- every call is a pass-through into core/cpp.
 *
 * PROOF-OF-CONCEPT scope, to inform the documented "15 Oct JNI+WASM go/no-go"
 * (core/cpp/bindings/jni/nav_jni.cpp, SIH26168_PROJECT_BIBLE.md §5.3) with
 * real data rather than presuming its outcome:
 *   - Only [createWithCampusGraph] exists -- the built-in synthetic demo
 *     graph (nav::defaultCampusGraph()), not a loaded OSM extract. Loading a
 *     real graph from an Android asset is the natural next step once the
 *     go/no-go is green; deliberately not built here so this stays a small,
 *     reviewable proof-of-concept rather than a half-finished production path.
 *   - [SimpleIns] is untouched and stays the RELATIVE-mode fallback (see its
 *     own file) for when no native graph is loaded, or if the go/no-go says
 *     no and this class is deleted entirely.
 *
 * INTEGRATION (see INTEGRATION.md for the exact gradle/CMake wiring):
 *   val engine = NativeEngine.createWithCampusGraph()
 *   engine.seed(lat, lon, headingDeg)
 *   // per IMU tick, after MountCalibrator/ZuptDetector/lean-solve already ran:
 *   val fix = engine.step(dt, speedMps, yawDeg, lux, baroHpa)
 *   // fix.mode / fix.edgeId / fix.branchPosteriors are exactly what a new
 *   // HudState field set (FUSED / MAP_AIDED_DR / AMBIGUOUS_JUNCTION / RELATIVE)
 *   // should be driven from -- see INTEGRATION.md for the mapping.
 *   engine.close() // in onDestroy / tearDown, mirrors GnssHub.stop() etc.
 */
class NativeEngine private constructor(private var handle: Long) : AutoCloseable {

    /** One call per IMU tick. Returns the freshly estimated fix; also cached internally. */
    fun seed(lat: Double, lon: Double, headingDeg: Double) {
        check(handle != 0L) { "NativeEngine already closed" }
        nativeSeed(handle, lat, lon, headingDeg)
    }

    fun step(dt: Double, speedMps: Double, yawDeg: Double, lux: Double = 0.0, baroHpa: Double = 1013.25): NativeFix {
        check(handle != 0L) { "NativeEngine already closed" }
        nativeStep(handle, dt, speedMps, yawDeg, lux, baroHpa)
        return NativeFix.parse(nativeEstimateJson(handle))
    }

    fun estimate(): NativeFix {
        check(handle != 0L) { "NativeEngine already closed" }
        return NativeFix.parse(nativeEstimateJson(handle))
    }

    override fun close() {
        if (handle != 0L) {
            nativeDestroy(handle)
            handle = 0L
        }
    }

    // --- native surface, one-to-one with nav_jni_bridge.cpp ---
    private external fun nativeSeed(h: Long, lat: Double, lon: Double, headingDeg: Double)
    private external fun nativeStep(h: Long, dt: Double, speed: Double, yawDeg: Double, lux: Double, baroHpa: Double)
    private external fun nativeEstimateJson(h: Long): String
    private external fun nativeDestroy(h: Long)

    companion object {
        init {
            // Matches the shared-library name in CMakeLists.txt (`add_library(navcore ...)`).
            System.loadLibrary("navcore")
        }

        @JvmStatic
        private external fun nativeCreateCampus(numParticles: Int, seed: Long): Long

        /** PROOF-OF-CONCEPT entry point — see class doc. Real-graph loading is a follow-up. */
        fun createWithCampusGraph(numParticles: Int = 256, seed: Long = 26168L): NativeEngine =
            NativeEngine(nativeCreateCampus(numParticles, seed))
    }
}

/**
 * Parsed mirror of nav_jni_bridge.cpp's toJson(INavState). Hand-rolled parsing (no new JSON
 * dependency beyond org.json, already used elsewhere in this app, e.g. CsvLogger.kt) since the
 * schema is small and fixed.
 */
data class NativeFix(
    val lat: Double,
    val lon: Double,
    val yawRad: Double,
    val speedMps: Double,
    val gnssAided: Boolean,
    val edgeId: String,
    val mode: String, // "gnss" | "ins" | "graph" | "coast" -- see nav::INavState.mode in types.h
    val branchPosteriors: Map<String, Double>,
) {
    /** Inverse-Simpson effective live-edge count -- see core/cpp's stratified_resample.h for the
     * canonical (native, floor-aware) version; this is the same formula applied client-side to
     * whatever branchPosteriors this fix reports, for a HUD-facing multi-modality indicator. */
    fun effectiveLiveEdges(): Double {
        val total = branchPosteriors.values.sum()
        if (total <= 0.0) return 0.0
        val sumSq = branchPosteriors.values.sumOf { val p = it / total; p * p }
        return if (sumSq > 0.0) 1.0 / sumSq else 0.0
    }

    companion object {
        fun parse(json: String): NativeFix {
            val o = org.json.JSONObject(json)
            val posteriors = LinkedHashMap<String, Double>()
            val bp = o.optJSONObject("branchPosteriors")
            if (bp != null) {
                val keys = bp.keys()
                while (keys.hasNext()) {
                    val key = keys.next()
                    posteriors[key] = bp.getDouble(key)
                }
            }
            return NativeFix(
                lat = o.optDouble("lat", 0.0),
                lon = o.optDouble("lon", 0.0),
                yawRad = o.optDouble("yaw", 0.0),
                speedMps = o.optDouble("speed", 0.0),
                gnssAided = o.optBoolean("gnssAided", false),
                edgeId = o.optString("edgeId", ""),
                mode = o.optString("mode", "coast"),
                branchPosteriors = posteriors,
            )
        }
    }
}
