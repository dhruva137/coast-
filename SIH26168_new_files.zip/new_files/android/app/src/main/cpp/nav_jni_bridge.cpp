// JNI bridge for in.sih26168.idr.nav.NativeEngine -> nav::GraphParticleFilter.
//
// core/cpp/bindings/jni/nav_jni.cpp is an intentional placeholder pending the
// documented "15 Oct JNI+WASM go/no-go" -- this file is a separate,
// self-contained proof-of-concept living under android/ instead, so it never
// touches that placeholder or presumes the outcome of that decision. If the
// go/no-go says yes, the content below is a reasonable starting point to
// migrate into nav_jni.cpp itself; if it says no, deleting this file plus its
// CMakeLists.txt fully removes it with no trace elsewhere in the app.
//
// Deliberately built around GraphParticleFilter::step() directly, not
// engine::runEngine() -- runEngine() takes whole std::vector<ISensorFrame>
// logs and returns a batch EngineResult (it's the offline replay/evaluation
// entry point used by the lab, not a live per-tick API). A phone calls this
// once per sensor tick, so the persistent-handle-around-step() design below
// is the one that actually fits a real-time caller.
//
// No estimator maths lives here -- every call is a direct pass-through into
// the existing, already-tested nav:: functions. If a bug shows up, it's in
// core/cpp, not in this file.

#include <jni.h>

#include <memory>
#include <sstream>

#include "nav/graphpf.h"
#include "nav/types.h"

namespace {

struct EngineHandle {
  nav::GraphParticleFilter pf;
  nav::INavState state;

  explicit EngineHandle(nav::GraphPfConfig cfg)
      : pf(nav::defaultCampusGraph(), cfg), state() {}
};

EngineHandle* asHandle(jlong h) { return reinterpret_cast<EngineHandle*>(h); }

std::string toJson(const nav::INavState& s) {
  std::ostringstream os;
  os.precision(8);
  os << "{"
     << "\"lat\":" << s.lat << ","
     << "\"lon\":" << s.lon << ","
     << "\"yaw\":" << s.yaw << ","
     << "\"speed\":" << s.speed << ","
     << "\"gnssAided\":" << (s.gnss_aided ? "true" : "false") << ","
     << "\"edgeId\":\"" << s.edge_id << "\","
     << "\"mode\":\"" << s.mode << "\","
     << "\"branchPosteriors\":{";
  bool first = true;
  for (const auto& kv : s.branch_posteriors) {
    if (!first) os << ",";
    os << "\"" << kv.first << "\":" << kv.second;
    first = false;
  }
  os << "}}";
  return os.str();
}

}  // namespace

extern "C" {

// Companion object, @JvmStatic -> compiles as a static method (jclass, not jobject).
// PROOF-OF-CONCEPT: only the built-in synthetic defaultCampusGraph() is wired up here
// (see nav::defaultCampusGraph in graphpf.cpp) -- loading a real OSM extract from an
// Android asset is deliberately out of scope for this first cut; see INTEGRATION.md.
JNIEXPORT jlong JNICALL
Java_in_sih26168_idr_nav_NativeEngine_nativeCreateCampus(JNIEnv*, jclass, jint num_particles, jlong seed) {
  nav::GraphPfConfig cfg;
  cfg.n = num_particles > 0 ? num_particles : 256;
  cfg.seed = static_cast<std::uint32_t>(seed);
  auto* handle = new EngineHandle(cfg);
  return reinterpret_cast<jlong>(handle);
}

JNIEXPORT void JNICALL
Java_in_sih26168_idr_nav_NativeEngine_nativeSeed(JNIEnv*, jobject, jlong h, jdouble lat, jdouble lon, jdouble heading_deg) {
  auto* handle = asHandle(h);
  if (!handle) return;
  handle->pf.seed(lat, lon, heading_deg);
}

JNIEXPORT void JNICALL
Java_in_sih26168_idr_nav_NativeEngine_nativeStep(
    JNIEnv*, jobject, jlong h, jdouble dt, jdouble speed, jdouble yaw_deg, jdouble lux, jdouble baro_hpa) {
  auto* handle = asHandle(h);
  if (!handle) return;
  handle->pf.step(dt, speed, yaw_deg, lux, baro_hpa);
  handle->state = handle->pf.estimate(handle->state);
}

JNIEXPORT jstring JNICALL
Java_in_sih26168_idr_nav_NativeEngine_nativeEstimateJson(JNIEnv* env, jobject, jlong h) {
  auto* handle = asHandle(h);
  if (!handle) return env->NewStringUTF("{}");
  return env->NewStringUTF(toJson(handle->state).c_str());
}

JNIEXPORT void JNICALL
Java_in_sih26168_idr_nav_NativeEngine_nativeDestroy(JNIEnv*, jobject, jlong h) {
  delete asHandle(h);
}

}  // extern "C"
